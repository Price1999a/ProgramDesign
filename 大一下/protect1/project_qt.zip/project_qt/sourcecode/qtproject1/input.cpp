#include "stdafx.h"
#include "input.h"

input::input(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}

input::~input()
{
}

void input::slot_lineinput()
{
	

}
