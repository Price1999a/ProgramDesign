#include "stdafx.h"
#include "qtproject1_login.h"

project1login::project1login(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
}

project1login::~project1login()
{
}

void project1login::slot_inputnamepassword()
{

	
}